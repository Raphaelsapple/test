import 'babel-polyfill'
import Vue from 'vue'
import Cube from 'cube-ui'
import App from './App'
import router from './router'
import VueResource from 'vue-resource'
import axios from 'axios'
import 'common/stylus/index.styl'


import fastclick from 'fastclick'

Vue.use(VueResource)
Vue.use(Cube)
Vue.prototype.axios = axios

fastclick.attach(document.body)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  render: h => h(App),
  router
})
