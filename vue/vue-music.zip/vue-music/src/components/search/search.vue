<template>
    <div class="search-title">
        搜索页面
    </div>
</template>

<script type="text/ecmascript-6">

</script>

<style scoped lang="stylus" rel='stylesheet/stylus'>
@import "~common/stylus/variable"
.search-title
    font-size $font-size-medium-x 
</style>
